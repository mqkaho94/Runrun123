import unittest


class SmokeImportTests(unittest.TestCase):
    def test_import_app_module(self) -> None:
        import bot.app  # noqa: F401


if __name__ == "__main__":
    unittest.main()
