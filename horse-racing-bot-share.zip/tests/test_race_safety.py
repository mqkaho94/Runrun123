import asyncio
import sqlite3
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import bot.db as db_module
from bot.db import init_db
from bot.handlers.common import require_admin
from bot.handlers.race import cancel_game, run_game
from bot.repositories.bet_repo import (
    create_bet_history,
    get_group_contrib,
    get_group_net_ranking,
    get_yesterday_group_champion,
    place_bet_atomic,
    refund_open_bets,
    settle_bet_history,
    settle_race_round,
)
from bot.repositories.session_repo import save_race_session
from bot.repositories.wallet_repo import get_balance, try_deduct_balance
from bot.services.game_engine import HORSES_DATA
from bot.services.chat_state import get_chat_game
from bot.services.session_recovery import recover_inflight_sessions


class InMemoryDbTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = sqlite3.connect(":memory:", check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        db_module.db_conn = self.conn
        init_db()

    def tearDown(self) -> None:
        self.conn.close()
        db_module.db_conn = None


class SettlementSafetyTests(InMemoryDbTestCase):
    def test_settle_race_round_once_only(self) -> None:
        chat_id = 9001
        bets_for_session: dict[int, dict] = {}
        settlements: list[dict] = []

        for user_id, amount, status, payout in (
            (1, 20, "won", 300),
            (2, 20, "won", 150),
            (3, 20, "lost", 0),
        ):
            self.assertTrue(try_deduct_balance(chat_id, user_id, amount))
            history_id = create_bet_history(chat_id, user_id, f"user-{user_id}", 1, amount, "bet")
            bets_for_session[user_id] = {
                "horse": 1,
                "horse2": None,
                "amount": amount,
                "name": f"user-{user_id}",
                "bet_type": "bet",
                "history_id": history_id,
            }
            settlements.append(
                {
                    "user_id": user_id,
                    "amount": amount,
                    "status": status,
                    "payout": payout,
                    "history_id": history_id,
                }
            )

        save_race_session(chat_id, {"status": "running", "bets": bets_for_session, "race_context": None})
        result = settle_race_round(chat_id, settlements)
        self.assertTrue(result["applied"])
        self.assertEqual(get_balance(chat_id, 1), 380)
        self.assertEqual(get_balance(chat_id, 2), 230)
        self.assertEqual(get_balance(chat_id, 3), 80)
        contrib_after_first = get_group_contrib(chat_id, 10)

        result_2 = settle_race_round(chat_id, settlements)
        self.assertFalse(result_2["applied"])
        self.assertEqual(get_balance(chat_id, 1), 380)
        self.assertEqual(get_balance(chat_id, 2), 230)
        self.assertEqual(get_balance(chat_id, 3), 80)
        self.assertEqual(get_group_contrib(chat_id, 10), contrib_after_first)

    def test_refund_open_bets_no_double_refund(self) -> None:
        chat_id = 9002
        bets: dict[int, dict] = {}
        for user_id in (11, 12):
            amount = 30
            self.assertTrue(try_deduct_balance(chat_id, user_id, amount))
            history_id = create_bet_history(chat_id, user_id, f"user-{user_id}", 2, amount, "place")
            bets[user_id] = {
                "horse": 2,
                "horse2": None,
                "amount": amount,
                "name": f"user-{user_id}",
                "bet_type": "place",
                "history_id": history_id,
            }

        save_race_session(chat_id, {"status": "running", "bets": bets, "race_context": None})
        first = refund_open_bets(chat_id, bets, "refunded_error")
        self.assertTrue(first["applied"])
        self.assertEqual(sorted(first["refunded_user_ids"]), [11, 12])
        self.assertEqual(get_balance(chat_id, 11), 100)
        self.assertEqual(get_balance(chat_id, 12), 100)

        # Simulate accidental re-entry before cleanup.
        self.conn.execute("UPDATE race_sessions SET status = 'running' WHERE chat_id = ?", (chat_id,))
        self.conn.commit()
        second = refund_open_bets(chat_id, bets, "refunded_error")
        self.assertTrue(second["applied"])
        self.assertEqual(second["refunded_user_ids"], [])
        self.assertEqual(get_balance(chat_id, 11), 100)
        self.assertEqual(get_balance(chat_id, 12), 100)


class SessionRecoveryTests(InMemoryDbTestCase):
    def test_recover_inflight_sessions_is_idempotent(self) -> None:
        chat_id = 9003
        user_id = 21
        amount = 40
        self.assertTrue(try_deduct_balance(chat_id, user_id, amount))
        history_id = create_bet_history(chat_id, user_id, "recover-user", 3, amount, "lin")
        save_race_session(
            chat_id,
            {
                "status": "running",
                "bets": {
                    user_id: {
                        "horse": 3,
                        "horse2": 4,
                        "amount": amount,
                        "name": "recover-user",
                        "bet_type": "lin",
                        "history_id": history_id,
                    }
                },
                "race_context": None,
            },
        )

        asyncio.run(recover_inflight_sessions())
        balance_after_first = get_balance(chat_id, user_id)
        asyncio.run(recover_inflight_sessions())
        balance_after_second = get_balance(chat_id, user_id)

        self.assertEqual(balance_after_first, 100)
        self.assertEqual(balance_after_second, 100)


class BetPlacementAtomicTests(InMemoryDbTestCase):
    def test_place_bet_atomic_success(self) -> None:
        chat_id = 9004
        history_id = place_bet_atomic(
            chat_id=chat_id,
            user_id=100,
            user_name="atomic-user",
            horse_id=1,
            amount=25,
            bet_type="bet",
        )
        self.assertIsNotNone(history_id)
        self.assertEqual(get_balance(chat_id, 100), 75)

    def test_place_bet_atomic_rolls_back_on_history_error(self) -> None:
        chat_id = 9005
        with self.assertRaises(sqlite3.IntegrityError):
            # user_name is NOT NULL in bet_history, forcing insert failure.
            place_bet_atomic(
                chat_id=chat_id,
                user_id=101,
                user_name=None,  # type: ignore[arg-type]
                horse_id=1,
                amount=25,
                bet_type="bet",
            )
        self.assertEqual(get_balance(chat_id, 101), 100)


class GroupAdminGateTests(unittest.IsolatedAsyncioTestCase):
    async def test_require_admin_rejects_private_chat(self) -> None:
        message = SimpleNamespace(reply_text=AsyncMock())
        update = SimpleNamespace(
            effective_chat=SimpleNamespace(type="private", id=1),
            effective_user=SimpleNamespace(id=7),
            effective_message=message,
        )
        context = SimpleNamespace(bot=SimpleNamespace(get_chat_member=AsyncMock()))
        allowed = await require_admin(update, context)
        self.assertFalse(allowed)
        context.bot.get_chat_member.assert_not_called()
        message.reply_text.assert_awaited_once()

    async def test_require_admin_accepts_group_admin(self) -> None:
        message = SimpleNamespace(reply_text=AsyncMock())
        update = SimpleNamespace(
            effective_chat=SimpleNamespace(type="group", id=99),
            effective_user=SimpleNamespace(id=8),
            effective_message=message,
        )
        context = SimpleNamespace(
            bot=SimpleNamespace(get_chat_member=AsyncMock(return_value=SimpleNamespace(status="administrator")))
        )
        allowed = await require_admin(update, context)
        self.assertTrue(allowed)
        message.reply_text.assert_not_called()


class CancelGameSafetyTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.conn = sqlite3.connect(":memory:", check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        db_module.db_conn = self.conn
        init_db()

    def tearDown(self) -> None:
        self.conn.close()
        db_module.db_conn = None

    async def test_cancel_game_only_refunds_open_bets(self) -> None:
        chat_id = 9010
        game = get_chat_game(chat_id)
        game["status"] = "betting"
        game["bets"] = {}

        for user_id in (31, 32):
            amount = 25
            self.assertTrue(try_deduct_balance(chat_id, user_id, amount))
            history_id = create_bet_history(chat_id, user_id, f"cancel-{user_id}", 1, amount, "bet")
            game["bets"][user_id] = {
                "horse": 1,
                "horse2": None,
                "amount": amount,
                "name": f"cancel-{user_id}",
                "bet_type": "bet",
                "history_id": history_id,
            }

        # Simulate a prior partial attempt: first user already refunded and history closed.
        first_history_id = int(game["bets"][31]["history_id"])
        self.conn.execute(
            """
            UPDATE bet_history
            SET status = 'refunded', payout = 25, result_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (first_history_id,),
        )
        self.conn.execute(
            "UPDATE wallets SET balance = balance + 25 WHERE chat_id = ? AND user_id = ?",
            (chat_id, 31),
        )
        self.conn.commit()
        save_race_session(chat_id, {"status": "betting", "bets": game["bets"], "race_context": None})

        message = SimpleNamespace(reply_text=AsyncMock(), chat=SimpleNamespace(id=chat_id, type="group"))
        update = SimpleNamespace(
            effective_message=message,
            effective_chat=SimpleNamespace(id=chat_id, type="group"),
            effective_user=SimpleNamespace(id=999),
        )
        context = SimpleNamespace()

        with patch("bot.handlers.race.require_admin", new=AsyncMock(return_value=True)):
            await cancel_game(update, context)

        self.assertEqual(get_balance(chat_id, 31), 100)
        self.assertEqual(get_balance(chat_id, 32), 100)


class RunGameFailurePathTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.conn = sqlite3.connect(":memory:", check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        db_module.db_conn = self.conn
        init_db()

    def tearDown(self) -> None:
        self.conn.close()
        db_module.db_conn = None

    async def test_run_game_reply_failure_after_settlement_does_not_refund_twice(self) -> None:
        chat_id = 9020
        user_id = 41
        amount = 20
        self.assertTrue(try_deduct_balance(chat_id, user_id, amount))
        history_id = create_bet_history(chat_id, user_id, "runner", 1, amount, "bet")

        game = get_chat_game(chat_id)
        game["status"] = "betting"
        game["bets"] = {
            user_id: {
                "horse": 1,
                "horse2": None,
                "amount": amount,
                "name": "runner",
                "bet_type": "bet",
                "history_id": history_id,
            }
        }
        game["race_context"] = None

        status_msg = SimpleNamespace(edit_text=AsyncMock())
        message = SimpleNamespace(
            reply_text=AsyncMock(side_effect=[None, status_msg, RuntimeError("send failed"), None]),
            chat=SimpleNamespace(id=chat_id, type="group", title="test-group"),
        )
        update = SimpleNamespace(
            effective_message=message,
            effective_chat=SimpleNamespace(id=chat_id, type="group", title="test-group"),
            effective_user=SimpleNamespace(id=999),
        )
        context = SimpleNamespace()

        with (
            patch("bot.handlers.race.require_admin", new=AsyncMock(return_value=True)),
            patch("bot.handlers.race.close_betting_buttons", new=AsyncMock()),
            patch("bot.handlers.race.pick_weighted_winner", side_effect=[1, 2, 3]),
            patch("bot.handlers.race.asyncio.sleep", new=AsyncMock()),
        ):
            await run_game(update, context)

        expected_payout = int(amount * float(HORSES_DATA[0]["odds"]))
        self.assertEqual(get_balance(chat_id, user_id), 100 - amount + expected_payout)


class StatsAggregationTests(InMemoryDbTestCase):
    def test_status_score_effects_are_correct(self) -> None:
        cases = [
            ("won", 9101, 60, 20, 40),
            ("lost", 9102, 0, 20, -20),
        ]
        for status, chat_id, payout, amount, expected_score in cases:
            user_id = chat_id
            self.assertTrue(try_deduct_balance(chat_id, user_id, amount))
            history_id = create_bet_history(chat_id, user_id, f"user-{user_id}", 1, amount, "bet")
            save_race_session(
                chat_id,
                {
                    "status": "running",
                    "bets": {
                        user_id: {
                            "horse": 1,
                            "horse2": None,
                            "amount": amount,
                            "name": f"user-{user_id}",
                            "bet_type": "bet",
                            "history_id": history_id,
                        }
                    },
                    "race_context": None,
                },
            )
            settle_race_round(
                chat_id,
                [
                    {
                        "user_id": user_id,
                        "amount": amount,
                        "status": status,
                        "payout": payout,
                        "history_id": history_id,
                        "name": f"user-{user_id}",
                        "bet_type": "bet",
                    }
                ],
            )
            contrib = get_group_contrib(chat_id, 1)
            self.assertEqual(contrib[0][2], expected_score)

        for refund_status, chat_id in (
            ("refunded", 9103),
            ("refunded_error", 9104),
            ("refunded_restart", 9105),
        ):
            user_id = chat_id
            amount = 20
            self.assertTrue(try_deduct_balance(chat_id, user_id, amount))
            history_id = create_bet_history(chat_id, user_id, f"user-{user_id}", 1, amount, "bet")
            bets = {
                user_id: {
                    "horse": 1,
                    "horse2": None,
                    "amount": amount,
                    "name": f"user-{user_id}",
                    "bet_type": "bet",
                    "history_id": history_id,
                }
            }
            save_race_session(chat_id, {"status": "running", "bets": bets, "race_context": None})
            refund_open_bets(chat_id, bets, refund_status)
            contrib = get_group_contrib(chat_id, 1)
            self.assertEqual(len(contrib), 1)
            self.assertEqual(contrib[0][0], user_id)
            self.assertEqual(contrib[0][2], 0)
            rank_rows = get_group_net_ranking(20)
            self.assertIn((chat_id, 0), rank_rows)

    def test_summary_queries_match_legacy_basic_case(self) -> None:
        chat_id = 9200
        entries = [
            (501, "alice", 20, "won", 60),
            (502, "bob", 20, "lost", 0),
        ]
        settlements: list[dict] = []
        bets_for_session: dict[int, dict] = {}
        for user_id, name, amount, status, payout in entries:
            self.assertTrue(try_deduct_balance(chat_id, user_id, amount))
            history_id = create_bet_history(chat_id, user_id, name, 1, amount, "bet")
            settlements.append(
                {
                    "user_id": user_id,
                    "amount": amount,
                    "status": status,
                    "payout": payout,
                    "history_id": history_id,
                    "name": name,
                    "bet_type": "bet",
                }
            )
            bets_for_session[user_id] = {
                "horse": 1,
                "horse2": None,
                "amount": amount,
                "name": name,
                "bet_type": "bet",
                "history_id": history_id,
            }
        save_race_session(chat_id, {"status": "running", "bets": bets_for_session, "race_context": None})
        settle_race_round(chat_id, settlements)

        summary_rank = get_group_net_ranking(10)
        summary_contrib = get_group_contrib(chat_id, 10)
        legacy_rank = self.conn.execute(
            """
            SELECT chat_id,
                   SUM(CASE WHEN status = 'won' THEN payout - amount
                            WHEN status = 'lost' THEN -amount
                            ELSE 0 END) AS net_score
            FROM bet_history
            GROUP BY chat_id
            ORDER BY net_score DESC
            LIMIT 10
            """
        ).fetchall()
        legacy_contrib = self.conn.execute(
            """
            SELECT user_id, MAX(user_name) AS user_name,
                   SUM(CASE WHEN status = 'won' THEN payout - amount
                            WHEN status = 'lost' THEN -amount
                            ELSE 0 END) AS net_score
            FROM bet_history
            WHERE chat_id = ?
            GROUP BY user_id
            ORDER BY net_score DESC
            LIMIT 10
            """,
            (chat_id,),
        ).fetchall()
        self.assertEqual(summary_rank, [(int(r[0]), int(r[1] or 0)) for r in legacy_rank])
        self.assertEqual(summary_contrib, [(int(r[0]), str(r[1]), int(r[2] or 0)) for r in legacy_contrib])

        self.conn.execute(
            "UPDATE bet_history SET result_at = DATETIME('now', '-1 day') WHERE chat_id = ?",
            (chat_id,),
        )
        self.conn.execute(
            "UPDATE group_user_daily_stats SET stat_date = DATE('now', '-1 day') WHERE chat_id = ?",
            (chat_id,),
        )
        self.conn.commit()
        summary_yesterday = get_yesterday_group_champion(chat_id)
        legacy_yesterday = self.conn.execute(
            """
            SELECT user_id, MAX(user_name) AS user_name,
                   SUM(CASE WHEN status = 'won' THEN payout - amount
                            WHEN status = 'lost' THEN -amount
                            ELSE 0 END) AS net_score
            FROM bet_history
            WHERE chat_id = ? AND DATE(COALESCE(result_at, created_at)) = DATE('now', '-1 day')
            GROUP BY user_id
            ORDER BY net_score DESC
            LIMIT 1
            """,
            (chat_id,),
        ).fetchone()
        expected = None if legacy_yesterday is None else (
            int(legacy_yesterday[0]),
            str(legacy_yesterday[1]),
            int(legacy_yesterday[2] or 0),
        )
        self.assertEqual(summary_yesterday, expected)

    def test_legacy_settle_api_is_blocked(self) -> None:
        with self.assertRaises(RuntimeError):
            settle_bet_history(1, "won", 100)

