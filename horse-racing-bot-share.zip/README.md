# Telegram Horse Racing Bot
# Telegram 賽馬 Bot

Python Telegram group game bot with wallet, betting, race engine, payout settlement, and session recovery.
用 Python 寫嘅 Telegram 群組賽馬遊戲 Bot，包含錢包、投注、賽事引擎、派彩結算同重啟恢復。

---
---

## Overview
## 概覽

- Group-based horse racing game (`python-telegram-bot 22.7`)
- Telegram 群組賽馬遊戲（`python-telegram-bot 22.7`）
- Per-chat wallet and race state isolation
- 每個 chat 都有獨立錢包同賽事狀態
- Bet types: Win (`/bet`), Place (`/place`), Quinella (`/lin`)
- 支援投注：獨贏（`/bet`）、位置（`/place`）、連贏（`/lin`）
- Auto-refund safety: `refunded_error` and `refunded_restart`
- 內建自動退款保護：`refunded_error` 同 `refunded_restart`
- Idempotent settlement/refund flow to prevent double payout or double refund
- 結算與退款流程具 idempotency，避免重複派彩或重複退款
- SQLite persistence with WAL + busy timeout
- SQLite 持久化，啟用 WAL 同 busy timeout
- Aggregated leaderboard stats tables for fast ranking queries
- 內建排行榜彙總統計表，提升榜單查詢效能

## Project Structure
## 專案結構

```text
bot/
  app.py                     # entrypoint, handler registration, polling
  config.py                  # env parsing, constants, logging setup
  db.py                      # sqlite connection, pragmas, schema/migration, run_db
  types.py                   # lightweight typed dicts
  repositories/
    wallet_repo.py
    bet_repo.py
    session_repo.py
  services/
    game_engine.py           # race context/weights/payout helpers
    chat_state.py            # in-memory per-chat state + TTL cleanup
    session_recovery.py      # startup recovery + restart refund
  handlers/
    wallet.py
    race.py
    history.py
    admin.py
    misc.py
    common.py
```

## Requirements
## 需求

- Python 3.11+ (3.12 recommended)
- Python 3.11+（建議 3.12）
- Telegram Bot token from BotFather
- 需要 BotFather 申請嘅 Telegram Bot token

## Install Dependencies
## 安裝相依套件

```bash
pip install -r requirements.txt
```

## Environment Variables
## 環境變數

Create `.env` (or export directly).
建立 `.env`（或者直接 export）。

```env
BOT_TOKEN=
BOT_OWNER_ID=
DB_PATH=data/wallets.db
INITIAL_COINS=100
BET_AMOUNT=100
RACE_TICKS=4
TICK_DELAY_SECONDS=1.2
BLESSING_CHANCE=0.1
DB_BUSY_TIMEOUT_MS=5000
CHAT_STATE_TTL_SECONDS=86400
LOG_LEVEL=INFO
```

All keys above are required for behavior parity with the current refactored bot.
以上 keys 會用嚟保持而家重構版同原行為一致。

## Run Locally
## 本機啟動

```bash
python -m bot.app
```

## Run with Docker
## 用 Docker 啟動

```bash
docker compose up --build
```

## Main Commands
## 主要指令

Player commands: `/start`, `/help`, `/balance`, `/history`, `/leaderboard`.
玩家指令：`/start`、`/help`、`/balance`、`/history`、`/leaderboard`。

Bet commands: `/bet <horse> <amount|%>`, `/place <horse> <amount|%>`, `/lin <horse1> <horse2> <amount|%>`.
投注指令：`/bet <馬號> <金額|%>`、`/place <馬號> <金額|%>`、`/lin <馬號1> <馬號2> <金額|%>`。

Ranking commands: `/rank`, `/grouprank`, `/groupcontrib`, `/yesterday`.
排行榜指令：`/rank`、`/grouprank`、`/groupcontrib`、`/yesterday`。

Admin commands: `/open` or `/startrace`, `/run`, `/cancel`.
管理員指令：`/open` 或 `/startrace`、`/run`、`/cancel`。

Owner-only command: `/reset_wallets`.
Bot 擁有者限定指令：`/reset_wallets`。

## Notes
## 備註

Entry point is now `python -m bot.app`.
目前正式入口係 `python -m bot.app`。

`horse_racing_bot_clean.py` has been removed.
`horse_racing_bot_clean.py` 已經移除。

The refactor is structure-focused and keeps game behavior unchanged.
今次重構集中喺結構整理，遊戲行為保持不變。

`bet_repo.settle_bet_history` is intentionally blocked. Use
`settle_race_round` / `refund_open_bets` for all settlement and refund writes.
`bet_repo.settle_bet_history` 已刻意封鎖；請統一使用
`settle_race_round` / `refund_open_bets` 進行結算與退款寫入。
