import logging
import os

TOKEN = os.getenv("BOT_TOKEN", "")
DB_PATH = os.getenv("DB_PATH", "data/wallets.db")
BOT_OWNER_ID_RAW = os.getenv("BOT_OWNER_ID", "").strip()
BOT_OWNER_ID = int(BOT_OWNER_ID_RAW) if BOT_OWNER_ID_RAW.isdigit() else None
INITIAL_COINS = int(os.getenv("INITIAL_COINS", "100"))
BET_AMOUNT = int(os.getenv("BET_AMOUNT", "100"))
RACE_TICKS = int(os.getenv("RACE_TICKS", "4"))
TICK_DELAY_SECONDS = float(os.getenv("TICK_DELAY_SECONDS", "1.2"))
DB_BUSY_TIMEOUT_MS = int(os.getenv("DB_BUSY_TIMEOUT_MS", "5000"))
CHAT_STATE_TTL_SECONDS = int(os.getenv("CHAT_STATE_TTL_SECONDS", str(24 * 60 * 60)))
BLESSING_CHANCE = float(os.getenv("BLESSING_CHANCE", "0.1"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()


def setup_logging() -> None:
    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=LOG_LEVEL,
    )


def validate_env() -> None:
    if not TOKEN:
        raise RuntimeError("BOT_TOKEN 未設定。請透過環境變數提供 Telegram Bot Token。")
