from bot.config import INITIAL_COINS
from bot.db import db_lock, get_db_conn


def ensure_user_wallet(chat_id: int, user_id: int) -> None:
    conn = get_db_conn()
    with db_lock:
        conn.execute(
            """
            INSERT OR IGNORE INTO wallets (chat_id, user_id, balance)
            VALUES (?, ?, ?)
            """,
            (chat_id, user_id, INITIAL_COINS),
        )
        conn.commit()


def get_balance(chat_id: int, user_id: int) -> int:
    ensure_user_wallet(chat_id, user_id)
    conn = get_db_conn()
    with db_lock:
        row = conn.execute(
            "SELECT balance FROM wallets WHERE chat_id = ? AND user_id = ?",
            (chat_id, user_id),
        ).fetchone()
        return int(row[0]) if row else INITIAL_COINS


def try_deduct_balance(chat_id: int, user_id: int, amount: int) -> bool:
    ensure_user_wallet(chat_id, user_id)
    conn = get_db_conn()
    with db_lock:
        cur = conn.execute(
            """
            UPDATE wallets
            SET balance = balance - ?
            WHERE chat_id = ? AND user_id = ? AND balance >= ?
            """,
            (amount, chat_id, user_id, amount),
        )
        conn.commit()
        return cur.rowcount == 1


def add_balance(chat_id: int, user_id: int, amount: int) -> None:
    ensure_user_wallet(chat_id, user_id)
    conn = get_db_conn()
    with db_lock:
        conn.execute(
            """
            UPDATE wallets
            SET balance = balance + ?
            WHERE chat_id = ? AND user_id = ?
            """,
            (amount, chat_id, user_id),
        )
        conn.commit()


def get_leaderboard(chat_id: int, limit: int = 10) -> list[tuple[int, int]]:
    conn = get_db_conn()
    with db_lock:
        rows = conn.execute(
            """
            SELECT user_id, balance
            FROM wallets
            WHERE chat_id = ?
            ORDER BY balance DESC
            LIMIT ?
            """,
            (chat_id, limit),
        ).fetchall()
        return [(int(row[0]), int(row[1])) for row in rows]


def reset_all_wallets(chat_id: int, new_balance: int) -> int:
    conn = get_db_conn()
    with db_lock:
        total_users = conn.execute(
            "SELECT COUNT(*) FROM wallets WHERE chat_id = ?",
            (chat_id,),
        ).fetchone()[0]
        conn.execute(
            """
            UPDATE wallets
            SET balance = ?
            WHERE chat_id = ?
            """,
            (new_balance, chat_id),
        )
        conn.commit()
        return int(total_users)
