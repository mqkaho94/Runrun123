import json

from bot.db import db_lock, get_db_conn


def save_race_session(chat_id: int, game: dict) -> None:
    conn = get_db_conn()
    session_status = game.get("status", "idle")
    race_context_json = json.dumps(game.get("race_context")) if game.get("race_context") else None
    bet_message_id = game.get("bet_message_id")
    with db_lock:
        conn.execute(
            """
            INSERT INTO race_sessions (chat_id, status, race_context_json, bet_message_id, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(chat_id) DO UPDATE SET
                status=excluded.status,
                race_context_json=excluded.race_context_json,
                bet_message_id=excluded.bet_message_id,
                updated_at=CURRENT_TIMESTAMP
            """,
            (chat_id, session_status, race_context_json, bet_message_id),
        )
        conn.execute("DELETE FROM race_session_bets WHERE chat_id = ?", (chat_id,))
        for user_id, bet in game.get("bets", {}).items():
            conn.execute(
                """
                INSERT INTO race_session_bets (chat_id, user_id, horse, horse2, amount, name, bet_type, history_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    chat_id,
                    int(user_id),
                    int(bet["horse"]),
                    bet.get("horse2"),
                    int(bet["amount"]),
                    str(bet["name"]),
                    str(bet.get("bet_type", "bet")),
                    bet.get("history_id"),
                ),
            )
        conn.commit()


def clear_race_session(chat_id: int) -> None:
    conn = get_db_conn()
    with db_lock:
        conn.execute("DELETE FROM race_session_bets WHERE chat_id = ?", (chat_id,))
        conn.execute("DELETE FROM race_sessions WHERE chat_id = ?", (chat_id,))
        conn.commit()


def load_active_race_sessions() -> list[dict]:
    conn = get_db_conn()
    with db_lock:
        sessions = conn.execute(
            """
            SELECT chat_id, status, race_context_json, bet_message_id
            FROM race_sessions
            WHERE status IN ('betting', 'running')
            """
        ).fetchall()
        results: list[dict] = []
        for session in sessions:
            chat_id = int(session["chat_id"])
            bets_rows = conn.execute(
                """
                SELECT user_id, horse, horse2, amount, name, bet_type, history_id
                FROM race_session_bets
                WHERE chat_id = ?
                """,
                (chat_id,),
            ).fetchall()
            bets = {
                int(row["user_id"]): {
                    "horse": int(row["horse"]),
                    "horse2": row["horse2"],
                    "amount": int(row["amount"]),
                    "name": str(row["name"]),
                    "bet_type": str(row["bet_type"]),
                    "history_id": row["history_id"],
                }
                for row in bets_rows
            }
            race_context = json.loads(session["race_context_json"]) if session["race_context_json"] else None
            results.append(
                {
                    "chat_id": chat_id,
                    "status": str(session["status"]),
                    "bet_message_id": session["bet_message_id"],
                    "race_context": race_context,
                    "bets": bets,
                }
            )
        return results
