from collections.abc import Sequence
from typing import Any

from bot.config import INITIAL_COINS
from bot.db import db_lock, get_db_conn


def create_bet_history(
    chat_id: int,
    user_id: int,
    user_name: str,
    horse_id: int,
    amount: int,
    bet_type: str = "bet",
    horse_id_2: int | None = None,
) -> int:
    conn = get_db_conn()
    with db_lock:
        cur = conn.execute(
            """
            INSERT INTO bet_history (chat_id, user_id, user_name, horse_id, horse_id_2, amount, bet_type, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'open')
            """,
            (chat_id, user_id, user_name, horse_id, horse_id_2, amount, bet_type),
        )
        conn.commit()
        return int(cur.lastrowid)


def place_bet_atomic(
    chat_id: int,
    user_id: int,
    user_name: str,
    horse_id: int,
    amount: int,
    bet_type: str = "bet",
    horse_id_2: int | None = None,
) -> int | None:
    """
    Atomically deduct balance and create bet history.
    Returns history id when successful, or None when balance is insufficient.
    """
    conn = get_db_conn()
    with db_lock:
        conn.execute("BEGIN")
        try:
            conn.execute(
                """
                INSERT OR IGNORE INTO wallets (chat_id, user_id, balance)
                VALUES (?, ?, ?)
                """,
                (chat_id, user_id, INITIAL_COINS),
            )
            deducted = conn.execute(
                """
                UPDATE wallets
                SET balance = balance - ?
                WHERE chat_id = ? AND user_id = ? AND balance >= ?
                """,
                (amount, chat_id, user_id, amount),
            )
            if deducted.rowcount != 1:
                conn.rollback()
                return None
            cur = conn.execute(
                """
                INSERT INTO bet_history (chat_id, user_id, user_name, horse_id, horse_id_2, amount, bet_type, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'open')
                """,
                (chat_id, user_id, user_name, horse_id, horse_id_2, amount, bet_type),
            )
            history_id = int(cur.lastrowid)
            conn.commit()
            return history_id
        except Exception:
            conn.rollback()
            raise


def settle_bet_history(history_id: int, status: str, payout: int = 0) -> None:
    raise RuntimeError("Use settle_race_round/refund_open_bets")


def _mark_session_settled(
    conn,
    chat_id: int,
    allowed_session_statuses: Sequence[str],
    session_final_status: str,
) -> bool:
    if not allowed_session_statuses:
        return False
    placeholders = ", ".join("?" for _ in allowed_session_statuses)
    cur = conn.execute(
        f"""
        UPDATE race_sessions
        SET status = ?, updated_at = CURRENT_TIMESTAMP
        WHERE chat_id = ? AND status IN ({placeholders})
        """,
        (session_final_status, chat_id, *allowed_session_statuses),
    )
    if cur.rowcount == 1:
        return True
    existing = conn.execute(
        "SELECT status FROM race_sessions WHERE chat_id = ?",
        (chat_id,),
    ).fetchone()
    if existing is None:
        conn.execute(
            """
            INSERT INTO race_sessions (chat_id, status, race_context_json, bet_message_id, updated_at)
            VALUES (?, ?, NULL, NULL, CURRENT_TIMESTAMP)
            """,
            (chat_id, session_final_status),
        )
        return True
    return False


def _credit_wallet(conn, chat_id: int, user_id: int, amount: int) -> None:
    conn.execute(
        """
        INSERT OR IGNORE INTO wallets (chat_id, user_id, balance)
        VALUES (?, ?, ?)
        """,
        (chat_id, user_id, INITIAL_COINS),
    )
    conn.execute(
        """
        UPDATE wallets
        SET balance = balance + ?
        WHERE chat_id = ? AND user_id = ?
        """,
        (amount, chat_id, user_id),
    )


def _score_delta(status: str, amount: int, payout: int) -> int:
    if status == "won":
        return payout - amount
    if status == "lost":
        return -amount
    return 0


def _apply_stats_delta(conn, chat_id: int, user_id: int, user_name: str, delta: int) -> None:
    conn.execute(
        """
        INSERT INTO group_stats (chat_id, net_score, updated_at)
        VALUES (?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(chat_id) DO UPDATE SET
            net_score = group_stats.net_score + excluded.net_score,
            updated_at = CURRENT_TIMESTAMP
        """,
        (chat_id, delta),
    )
    conn.execute(
        """
        INSERT INTO group_user_stats (chat_id, user_id, user_name, net_score, updated_at)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(chat_id, user_id) DO UPDATE SET
            user_name = excluded.user_name,
            net_score = group_user_stats.net_score + excluded.net_score,
            updated_at = CURRENT_TIMESTAMP
        """,
        (chat_id, user_id, user_name, delta),
    )
    conn.execute(
        """
        INSERT INTO group_user_daily_stats (stat_date, chat_id, user_id, user_name, net_score, updated_at)
        VALUES (DATE('now'), ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(stat_date, chat_id, user_id) DO UPDATE SET
            user_name = excluded.user_name,
            net_score = group_user_daily_stats.net_score + excluded.net_score,
            updated_at = CURRENT_TIMESTAMP
        """,
        (chat_id, user_id, user_name, delta),
    )


def settle_race_round(
    chat_id: int,
    settlements: list[dict[str, Any]],
    allowed_session_statuses: Sequence[str] = ("running",),
    session_final_status: str = "settled",
) -> dict[str, Any]:
    """
    Apply race settlement atomically.

    Each settlement item expects:
    {user_id, amount, status, payout, history_id?}
    """
    conn = get_db_conn()
    applied_user_ids: list[int] = []
    skipped_user_ids: list[int] = []
    with db_lock:
        conn.execute("BEGIN")
        try:
            if not _mark_session_settled(conn, chat_id, allowed_session_statuses, session_final_status):
                conn.rollback()
                return {"applied": False, "applied_user_ids": [], "skipped_user_ids": []}

            for item in settlements:
                user_id = int(item["user_id"])
                payout = int(item.get("payout", 0))
                history_id = item.get("history_id")
                should_apply = True
                if history_id:
                    cur = conn.execute(
                        """
                        UPDATE bet_history
                        SET status = ?, payout = ?, result_at = CURRENT_TIMESTAMP
                        WHERE id = ? AND chat_id = ? AND status = 'open'
                        """,
                        (
                            str(item["status"]),
                            payout,
                            int(history_id),
                            chat_id,
                        ),
                    )
                    should_apply = cur.rowcount == 1
                if not should_apply:
                    skipped_user_ids.append(user_id)
                    continue
                if payout > 0:
                    _credit_wallet(conn, chat_id, user_id, payout)
                delta = _score_delta(str(item["status"]), int(item.get("amount", 0)), payout)
                _apply_stats_delta(conn, chat_id, user_id, str(item.get("name", f"user-{user_id}")), delta)
                applied_user_ids.append(user_id)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
    return {
        "applied": True,
        "applied_user_ids": applied_user_ids,
        "skipped_user_ids": skipped_user_ids,
    }


def refund_open_bets(
    chat_id: int,
    bets: dict[int, dict[str, Any]],
    refund_status: str,
    allowed_session_statuses: Sequence[str] = ("betting", "running"),
    session_final_status: str = "settled",
) -> dict[str, Any]:
    conn = get_db_conn()
    refunded_user_ids: list[int] = []
    skipped_user_ids: list[int] = []
    with db_lock:
        conn.execute("BEGIN")
        try:
            if not _mark_session_settled(conn, chat_id, allowed_session_statuses, session_final_status):
                conn.rollback()
                return {"applied": False, "refunded_user_ids": [], "skipped_user_ids": []}

            for raw_user_id, bet in bets.items():
                user_id = int(raw_user_id)
                amount = int(bet["amount"])
                history_id = bet.get("history_id")
                should_refund = True
                if history_id:
                    cur = conn.execute(
                        """
                        UPDATE bet_history
                        SET status = ?, payout = ?, result_at = CURRENT_TIMESTAMP
                        WHERE id = ? AND chat_id = ? AND status = 'open'
                        """,
                        (
                            refund_status,
                            amount,
                            int(history_id),
                            chat_id,
                        ),
                    )
                    should_refund = cur.rowcount == 1
                if not should_refund:
                    skipped_user_ids.append(user_id)
                    continue
                _credit_wallet(conn, chat_id, user_id, amount)
                delta = _score_delta(refund_status, amount, amount)
                _apply_stats_delta(conn, chat_id, user_id, str(bet.get("name", f"user-{user_id}")), delta)
                refunded_user_ids.append(user_id)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
    return {
        "applied": True,
        "refunded_user_ids": refunded_user_ids,
        "skipped_user_ids": skipped_user_ids,
    }


def get_user_history(chat_id: int, user_id: int, limit: int = 10) -> list[tuple]:
    conn = get_db_conn()
    with db_lock:
        return conn.execute(
            """
            SELECT created_at, bet_type, horse_id, horse_id_2, amount, status, payout
            FROM bet_history
            WHERE chat_id = ? AND user_id = ?
            ORDER BY id DESC
            LIMIT ?
            """,
            (chat_id, user_id, limit),
        ).fetchall()


def get_group_net_ranking(limit: int = 10) -> list[tuple[int, int]]:
    conn = get_db_conn()
    with db_lock:
        rows = conn.execute(
            """
            SELECT chat_id, net_score
            FROM group_stats
            ORDER BY net_score DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        if not rows:
            rows = conn.execute(
                """
                SELECT chat_id,
                       SUM(
                         CASE
                           WHEN status = 'won' THEN payout - amount
                           WHEN status = 'lost' THEN -amount
                           ELSE 0
                         END
                       ) AS net_score
                FROM bet_history
                GROUP BY chat_id
                ORDER BY net_score DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [(int(row[0]), int(row[1] or 0)) for row in rows]


def get_group_contrib(chat_id: int, limit: int = 10) -> list[tuple[int, str, int]]:
    conn = get_db_conn()
    with db_lock:
        rows = conn.execute(
            """
            SELECT user_id, user_name, net_score
            FROM group_user_stats
            WHERE chat_id = ?
            ORDER BY net_score DESC
            LIMIT ?
            """,
            (chat_id, limit),
        ).fetchall()
        if not rows:
            rows = conn.execute(
                """
                SELECT user_id, MAX(user_name) AS user_name,
                       SUM(
                         CASE
                           WHEN status = 'won' THEN payout - amount
                           WHEN status = 'lost' THEN -amount
                           ELSE 0
                         END
                       ) AS net_score
                FROM bet_history
                WHERE chat_id = ?
                GROUP BY user_id
                ORDER BY net_score DESC
                LIMIT ?
                """,
                (chat_id, limit),
            ).fetchall()
        return [(int(row[0]), str(row[1]), int(row[2] or 0)) for row in rows]


def get_yesterday_group_champion(chat_id: int) -> tuple[int, str, int] | None:
    conn = get_db_conn()
    with db_lock:
        row = conn.execute(
            """
            SELECT user_id, user_name, net_score
            FROM group_user_daily_stats
            WHERE chat_id = ? AND stat_date = DATE('now', '-1 day')
            ORDER BY net_score DESC
            LIMIT 1
            """,
            (chat_id,),
        ).fetchone()
        if not row:
            row = conn.execute(
                """
                SELECT user_id, MAX(user_name) AS user_name,
                       SUM(
                         CASE
                           WHEN status = 'won' THEN payout - amount
                           WHEN status = 'lost' THEN -amount
                           ELSE 0
                         END
                       ) AS net_score
                FROM bet_history
                WHERE chat_id = ?
                  AND DATE(COALESCE(result_at, created_at)) = DATE('now', '-1 day')
                GROUP BY user_id
                ORDER BY net_score DESC
                LIMIT 1
                """,
                (chat_id,),
            ).fetchone()
        if not row:
            return None
        return (int(row[0]), str(row[1]), int(row[2] or 0))
