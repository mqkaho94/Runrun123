from telegram import Update
from telegram.ext import ContextTypes

from bot.db import run_db
from bot.repositories.wallet_repo import ensure_user_wallet, get_balance, get_leaderboard


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    message = update.effective_message
    chat = update.effective_chat
    if user is None or message is None or chat is None:
        return

    await run_db(ensure_user_wallet, chat.id, user.id)
    balance = await run_db(get_balance, chat.id, user.id)
    user_name = user.first_name or "玩家"

    await message.reply_text(
        f"🏇 歡迎來到虛擬賽馬場，{user_name}！\n"
        f"💰 帳戶餘額：${balance} 金幣。\n"
        "管理員可以輸入 /open 或 /startrace 開盤，玩家可用 /help 睇玩法。"
    )


async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    message = update.effective_message
    chat = update.effective_chat
    if user is None or message is None or chat is None:
        return
    await run_db(ensure_user_wallet, chat.id, user.id)
    current_balance = await run_db(get_balance, chat.id, user.id)
    await message.reply_text(f"💰 你而家餘額：${current_balance} 金幣。")


async def leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    if message is None or chat is None:
        return

    rows = await run_db(get_leaderboard, chat.id, 10)
    if not rows:
        await message.reply_text("📉 目前仲未有任何玩家紀錄。")
        return

    text = "🏆 最有錢馬主（Top 10）\n\n"
    for idx, (user_id, coins) in enumerate(rows, start=1):
        text += f"{idx}. 玩家 {user_id}: ${coins}\n"
    await message.reply_text(text)
