from telegram import Update
from telegram.ext import ContextTypes

from bot.db import run_db
from bot.repositories.bet_repo import (
    get_group_contrib,
    get_group_net_ranking,
    get_user_history,
    get_yesterday_group_champion,
)


async def history(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    message = update.effective_message
    chat = update.effective_chat
    if user is None or message is None or chat is None:
        return

    rows = await run_db(get_user_history, chat.id, user.id, 10)
    if not rows:
        await message.reply_text("📜 你暫時未有投注紀錄。")
        return

    lines = ["📜 你最近 10 筆投注：", ""]
    for created_at, bet_type, horse_id, horse_id_2, amount, status, payout in rows:
        horse_text = f"馬#{horse_id}" if horse_id_2 is None else f"馬#{horse_id}+馬#{horse_id_2}"
        lines.append(
            f"- [{created_at}] {bet_type.upper()} {horse_text} ${amount} -> {status.upper()} (派彩 ${payout})"
        )
    await message.reply_text("\n".join(lines))


async def group_rank(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if message is None:
        return

    rows = await run_db(get_group_net_ranking, 10)
    if not rows:
        await message.reply_text("📉 暫時未有群組分數紀錄。")
        return

    text = "🏆 群組累積分數榜（Top 10）\n\n"
    for idx, (chat_id, score) in enumerate(rows, start=1):
        text += f"{idx}. 群組 {chat_id}: {score:+}\n"
    await message.reply_text(text)


async def group_contrib(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    if message is None or chat is None:
        return

    rows = await run_db(get_group_contrib, chat.id, 10)
    if not rows:
        await message.reply_text("📉 呢個群組暫時未有成員貢獻紀錄。")
        return

    text = "👥 成員貢獻榜（Top 10）\n\n"
    for idx, (_user_id, user_name, score) in enumerate(rows, start=1):
        tier = "🥇" if idx == 1 else "🥈" if idx == 2 else "🥉" if idx == 3 else "🏇"
        text += f"{idx}. {tier} {user_name}: {score:+}\n"
    await message.reply_text(text)


async def yesterday(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    if message is None or chat is None:
        return

    champ = await run_db(get_yesterday_group_champion, chat.id)
    if not champ:
        await message.reply_text("🌙 昨日暫時冇足夠紀錄產生冠軍。")
        return

    _user_id, user_name, score = champ
    await message.reply_text(f"🏆 昨日群組冠軍：{user_name}（淨分 {score:+}）")
