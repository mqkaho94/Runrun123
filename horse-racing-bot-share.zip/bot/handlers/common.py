import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from bot.services.game_engine import HORSES_DATA

logger = logging.getLogger(__name__)


async def is_group_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    chat = update.effective_chat
    user = update.effective_user
    if chat is None or user is None:
        return False
    if chat.type not in ("group", "supergroup"):
        return False

    member = await context.bot.get_chat_member(chat.id, user.id)
    return member.status in ("administrator", "creator")


async def require_group_chat(update: Update) -> bool:
    chat = update.effective_chat
    if chat is not None and chat.type in ("group", "supergroup"):
        return True
    if update.effective_message:
        await update.effective_message.reply_text("❌ 呢個指令只可以喺群組使用。")
    return False


async def require_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    if not await require_group_chat(update):
        return False
    if await is_group_admin(update, context):
        return True
    if update.effective_message:
        await update.effective_message.reply_text("❌ 只有群組管理員可以使用呢個指令。")
    return False


def bet_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(
                f"投注 {horse['id']} 號",
                callback_data=f"bet_{horse['id']}",
            )
        ]
        for horse in HORSES_DATA
    ]
    return InlineKeyboardMarkup(keyboard)


async def close_betting_buttons(context: ContextTypes.DEFAULT_TYPE, chat_id: int, game: dict) -> None:
    message_id = game.get("bet_message_id")
    if not message_id:
        return
    try:
        await context.bot.edit_message_reply_markup(chat_id=chat_id, message_id=message_id, reply_markup=None)
    except Exception:
        logger.debug("Failed to clear betting buttons for chat %s", chat_id)
    finally:
        game["bet_message_id"] = None


async def send_hidden_state_pm(
    context: ContextTypes.DEFAULT_TYPE,
    user_id: int,
    lines: list[str],
    race_title: str,
) -> bool:
    text = "📩 馬主私密情報（只限你睇）\n"
    text += f"🏁 {race_title}\n\n"
    text += "\n".join(lines)
    try:
        await context.bot.send_message(chat_id=user_id, text=text)
        return True
    except Exception:
        return False
