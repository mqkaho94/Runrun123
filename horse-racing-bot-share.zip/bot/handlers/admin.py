from telegram import Update
from telegram.ext import ContextTypes

from bot.config import BOT_OWNER_ID, INITIAL_COINS
from bot.db import run_db
from bot.repositories.wallet_repo import reset_all_wallets


async def reset_wallets(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user
    if message is None or chat is None:
        return
    if user is None:
        return

    if chat.type not in ("group", "supergroup"):
        await message.reply_text("❌ `/reset_wallets` 只可喺群組內使用。", parse_mode="Markdown")
        return

    if BOT_OWNER_ID is None:
        await message.reply_text("❌ Bot 未設定 `BOT_OWNER_ID`，已停用 `/reset_wallets`。", parse_mode="Markdown")
        return

    if user.id != BOT_OWNER_ID:
        await message.reply_text("❌ 只有 Bot 擁有者可以使用 `/reset_wallets`。", parse_mode="Markdown")
        return

    reset_count = await run_db(reset_all_wallets, chat.id, INITIAL_COINS)
    await message.reply_text(f"♻️ 已將 {reset_count} 位玩家餘額重設為 ${INITIAL_COINS}。")
