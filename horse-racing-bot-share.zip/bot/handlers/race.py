import asyncio
import logging
import random

from telegram import Update
from telegram.ext import ContextTypes

from bot.config import BET_AMOUNT, RACE_TICKS, TICK_DELAY_SECONDS
from bot.db import run_db
from bot.handlers.common import (
    bet_keyboard,
    close_betting_buttons,
    require_admin,
    send_hidden_state_pm,
)
from bot.repositories.bet_repo import (
    place_bet_atomic,
    refund_open_bets,
    settle_race_round,
)
from bot.repositories.wallet_repo import ensure_user_wallet, get_balance
from bot.services.chat_state import (
    clear_persisted_chat_game,
    get_chat_game,
    get_chat_lock,
    persist_chat_game,
)
from bot.services.game_engine import (
    HORSES_DATA,
    build_race_context,
    describe_public_state,
    format_hidden_state_line,
    get_effective_weights,
    get_lin_multiplier,
    get_place_multiplier,
    parse_bet_amount,
    pick_weighted_winner,
)

logger = logging.getLogger(__name__)


async def place_bet(
    chat_id: int,
    user_id: int,
    user_name: str,
    horse_id: int,
    amount: int,
    source_message,
    context: ContextTypes.DEFAULT_TYPE,
    bet_type: str = "bet",
    horse_id_2: int | None = None,
) -> bool:
    await run_db(ensure_user_wallet, chat_id, user_id)
    if not any(horse["id"] == horse_id for horse in HORSES_DATA):
        await source_message.reply_text("❌ 無效馬匹編號。")
        return False
    if bet_type == "lin":
        if horse_id_2 is None:
            await source_message.reply_text("❌ 連贏需要兩個馬號。")
            return False
        if horse_id_2 == horse_id:
            await source_message.reply_text("❌ 連贏兩匹馬唔可以相同。")
            return False
        if not any(horse["id"] == horse_id_2 for horse in HORSES_DATA):
            await source_message.reply_text("❌ 第二匹馬編號無效。")
            return False

    newly_owned_horses: list[int] = []
    lock = get_chat_lock(chat_id)
    async with lock:
        game = get_chat_game(chat_id)
        if game["status"] != "betting":
            await source_message.reply_text("❌ 抱歉，已經封盤或賽事尚未開始。")
            return False
        if game.get("race_context") is None:
            game["race_context"] = build_race_context()
        if user_id in game["bets"]:
            await source_message.reply_text(f"⚠️ {user_name}，你已經下注，不能重複下注。")
            return False
        history_id = await run_db(
            place_bet_atomic,
            chat_id,
            user_id,
            user_name,
            horse_id,
            amount,
            bet_type,
            horse_id_2,
        )
        if history_id is None:
            await source_message.reply_text(f"⚠️ {user_name}，你餘額不足，輸入 /balance 查餘額。")
            return False
        game["bets"][user_id] = {
            "horse": horse_id,
            "horse2": horse_id_2,
            "amount": amount,
            "name": user_name,
            "bet_type": bet_type,
            "history_id": history_id,
        }
        race_context = game["race_context"]
        owners = race_context.setdefault("owners", {})
        target_horses = [horse_id]
        if bet_type == "lin" and horse_id_2 is not None:
            target_horses.append(horse_id_2)
        for target_horse_id in target_horses:
            if target_horse_id not in owners:
                owners[target_horse_id] = {"user_id": user_id, "user_name": user_name}
                newly_owned_horses.append(target_horse_id)
        await persist_chat_game(chat_id)

    horse_name = next(horse["name"] for horse in HORSES_DATA if horse["id"] == horse_id)
    if bet_type == "bet":
        await source_message.reply_text(f"✅ {user_name} 成功為【{horse_name}】下注（獨贏）${amount}！")
    elif bet_type == "place":
        await source_message.reply_text(f"✅ {user_name} 成功為【{horse_name}】下注（位置）${amount}！")
    else:
        horse_name_2 = next(horse["name"] for horse in HORSES_DATA if horse["id"] == horse_id_2)
        await source_message.reply_text(
            f"✅ {user_name} 成功下注連贏【{horse_name}】+【{horse_name_2}】${amount}！"
        )

    if newly_owned_horses:
        race_title = f"第{chat_id}場（群組 {source_message.chat.title or chat_id}）"
        hidden_lines = [format_hidden_state_line(game["race_context"], hid) for hid in newly_owned_horses]
        hidden_lines.append("\n⏳ 呢啲隱藏狀態會喺開跑前向全場公開。")
        sent = await send_hidden_state_pm(context, user_id, hidden_lines, race_title)
        if not sent:
            await source_message.reply_text(
                "📭 未能私訊你隱藏狀態，請先私訊 Bot 輸入 /start 開啟對話。"
            )
    return True


async def open_game(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    if message is None or chat is None:
        return
    if not await require_admin(update, context):
        return

    chat_id = chat.id
    lock = get_chat_lock(chat_id)
    async with lock:
        game = get_chat_game(chat_id)
        if game["status"] != "idle":
            await message.reply_text("❌ 當前已有賽事進行中，請先完成或 /cancel。")
            return

        game["status"] = "betting"
        game["bets"] = {}
        game["horses"] = HORSES_DATA.copy()
        game["race_context"] = build_race_context()
        race_context = game["race_context"]

        text = f"🏁 【線上沙田馬場】新賽事已開盤！\n\n請選擇你要支持嘅馬匹（統一每注 ${BET_AMOUNT}）：\n"
        text += f"🏟️ 場地因素：{race_context['track']['name']}\n"
        if race_context["blessing"]:
            text += f"{race_context['blessing']['text']}\n"
        else:
            text += "🍃 本場未觸發隨機祝福。\n"
        text += "\n"
        for horse in HORSES_DATA:
            public_factor = race_context["horses"][horse["id"]]["public_factor"]
            public_desc = describe_public_state(public_factor)
            text += (
                f"{horse['id']}. {horse['name']} - 賠率 {horse['odds']}\n"
                f"　└ {public_desc} ({public_factor:+}%)\n"
            )
        text += "\n可按按鈕下注，或用：\n"
        text += "`/bet <馬號> <金額/百分比>`（獨贏）\n"
        text += "`/place <馬號> <金額/百分比>`（位置，前三名都算中）\n"
        text += "`/lin <馬號1> <馬號2> <金額/百分比>`（連贏）\n"
        text += "💌 每匹馬隱藏狀態會私訊俾首位馬主，並於開跑前公開。\n"
        text += "下注完成後，請管理員輸入 /run 開始比賽。"

        sent = await message.reply_text(text, reply_markup=bet_keyboard(), parse_mode="Markdown")
        game["bet_message_id"] = sent.message_id
        await persist_chat_game(chat_id)


async def handle_bet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if query is None or query.message is None or query.from_user is None:
        return
    await query.answer()

    chat_id = query.message.chat_id
    user_id = query.from_user.id
    user_name = query.from_user.first_name or "玩家"
    try:
        horse_id = int((query.data or "").split("_")[1])
    except (IndexError, ValueError):
        await query.message.reply_text("❌ 無效投注選項。")
        return

    await place_bet(chat_id, user_id, user_name, horse_id, BET_AMOUNT, query.message, context)


async def bet_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user
    if message is None or chat is None or user is None:
        return

    if len(context.args) != 2:
        await message.reply_text(
            "用法：`/bet <馬號> <金額/百分比>`\n例子：`/bet 1 100` 或 `/bet 2 10%`",
            parse_mode="Markdown",
        )
        return

    try:
        horse_id = int(context.args[0])
    except ValueError:
        await message.reply_text("❌ 馬號必須係數字，例如 `/bet 1 100`。", parse_mode="Markdown")
        return

    balance_now = await run_db(get_balance, chat.id, user.id)
    try:
        amount = parse_bet_amount(context.args[1], balance_now)
    except ValueError as exc:
        await message.reply_text(f"❌ {exc}")
        return

    await place_bet(
        chat.id,
        user.id,
        user.first_name or "玩家",
        horse_id,
        amount,
        message,
        context,
        bet_type="bet",
    )


async def place_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user
    if message is None or chat is None or user is None:
        return

    if len(context.args) != 2:
        await message.reply_text(
            "用法：`/place <馬號> <金額/百分比>`\n例子：`/place 1 200` 或 `/place 4 20%`",
            parse_mode="Markdown",
        )
        return

    try:
        horse_id = int(context.args[0])
    except ValueError:
        await message.reply_text("❌ 馬號必須係數字，例如 `/place 1 100`。", parse_mode="Markdown")
        return

    balance_now = await run_db(get_balance, chat.id, user.id)
    try:
        amount = parse_bet_amount(context.args[1], balance_now)
    except ValueError as exc:
        await message.reply_text(f"❌ {exc}")
        return

    await place_bet(
        chat.id,
        user.id,
        user.first_name or "玩家",
        horse_id,
        amount,
        message,
        context,
        bet_type="place",
    )


async def lin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user
    if message is None or chat is None or user is None:
        return

    if len(context.args) != 3:
        await message.reply_text(
            "用法：`/lin <馬號1> <馬號2> <金額/百分比>`\n例子：`/lin 1 2 100` 或 `/lin 2 4 10%`",
            parse_mode="Markdown",
        )
        return

    try:
        horse_id_1 = int(context.args[0])
        horse_id_2 = int(context.args[1])
    except ValueError:
        await message.reply_text("❌ 馬號必須係數字，例如 `/lin 1 2 100`。", parse_mode="Markdown")
        return

    balance_now = await run_db(get_balance, chat.id, user.id)
    try:
        amount = parse_bet_amount(context.args[2], balance_now)
    except ValueError as exc:
        await message.reply_text(f"❌ {exc}")
        return

    await place_bet(
        chat.id,
        user.id,
        user.first_name or "玩家",
        horse_id_1,
        amount,
        message,
        context,
        bet_type="lin",
        horse_id_2=horse_id_2,
    )


async def run_game(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    if message is None or chat is None:
        return
    if not await require_admin(update, context):
        return

    chat_id = chat.id
    lock = get_chat_lock(chat_id)

    bets_snapshot: dict[int, dict] = {}
    race_context: dict | None = None
    owners: dict[int, dict] = {}
    winner_id = second_id = third_id = -1
    winner_horse = second_horse = third_horse = None
    game = None

    async with lock:
        game = get_chat_game(chat_id)
        if game["status"] != "betting":
            await message.reply_text("❌ 目前冇可開始嘅賽事，請先輸入 /open。")
            return
        if not game["bets"]:
            await message.reply_text("❌ 目前未有人下注，唔可以開跑。")
            return

        game["status"] = "running"
        race_context = game.get("race_context") or build_race_context()
        game["race_context"] = race_context
        effective_weights = get_effective_weights(race_context)
        winner_id = pick_weighted_winner(effective_weights)
        second_id = pick_weighted_winner(effective_weights, excluded={winner_id})
        third_id = pick_weighted_winner(effective_weights, excluded={winner_id, second_id})
        winner_horse = next(horse for horse in HORSES_DATA if horse["id"] == winner_id)
        second_horse = next(horse for horse in HORSES_DATA if horse["id"] == second_id)
        third_horse = next(horse for horse in HORSES_DATA if horse["id"] == third_id)
        bets_snapshot = dict(game["bets"])
        owners = dict(race_context.get("owners", {}))
        await persist_chat_game(chat_id)

    try:
        await close_betting_buttons(context, chat_id, game)

        reveal_text = "🔓 開跑前公開：本場隱藏狀態\n\n"
        for horse in HORSES_DATA:
            horse_id = horse["id"]
            owner = owners.get(horse_id)
            owner_text = f"馬主：{owner['user_name']}" if owner else "馬主：未被認領"
            reveal_text += f"{horse_id}. {format_hidden_state_line(race_context, horse_id)} | {owner_text}\n"
        await message.reply_text(reveal_text)

        status_msg = await message.reply_text("🚧 閘門打開！馬匹正在衝刺... 🏇🏇🏇")
        tracks = {horse["id"]: 0 for horse in HORSES_DATA}

        for tick in range(RACE_TICKS):
            for horse in HORSES_DATA:
                gain = random.randint(1, 3)
                factor = race_context["horses"][horse["id"]]["total_factor"]
                if factor >= 20:
                    gain += 2
                elif factor >= 10:
                    gain += 1
                elif factor <= -12:
                    gain -= 1
                if horse["id"] == winner_id and tick >= RACE_TICKS // 2:
                    gain += 1
                if horse["id"] == second_id and tick >= RACE_TICKS // 2:
                    gain += 1
                if horse["id"] == third_id and tick >= RACE_TICKS // 2:
                    gain += 1
                tracks[horse["id"]] += max(1, gain)

            if tick == RACE_TICKS - 1:
                tracks[winner_id] = max(tracks.values()) + 1

            animation_text = "🏃‍♂️ 賽事進行中！衝刺！ 🏃‍♂️\n\n"
            for horse_id, progress in sorted(tracks.items()):
                safe_progress = min(progress, 12)
                track_line = "." * safe_progress + "🏇" + "." * (12 - safe_progress)
                animation_text += f"{horse_id}號: |{track_line}|\n"

            await status_msg.edit_text(animation_text)
            await asyncio.sleep(TICK_DELAY_SECONDS)

        result_text = (
            f"🏁 賽事結束！\n"
            f"🥇 冠軍馬匹係：【{winner_horse['name']}】\n\n"
            f"🥈 亞軍馬匹係：【{second_horse['name']}】\n\n"
            f"🥉 季軍馬匹係：【{third_horse['name']}】\n\n"
            f"🏟️ 場地：{race_context['track']['name']}\n"
        )
        if race_context["blessing"]:
            result_text += f"{race_context['blessing']['text']}\n"
        result_text += "\n📊 賽果因素（公開+私密+場地+祝福）：\n"
        for horse in HORSES_DATA:
            factors = race_context["horses"][horse["id"]]
            result_text += (
                f"{horse['id']}號 {horse['name']}: "
                f"{factors['total_factor']:+}% "
                f"(表 {factors['public_factor']:+}% / 私 {factors['private_factor']:+}% / "
                f"場地 {factors['track_factor']:+}% / 祝福 {factors['blessing_factor']:+}%)\n"
            )
        result_text += "\n💰 派彩結果：\n"
        settlement_entries: list[dict] = []
        for user_id, bet in bets_snapshot.items():
            bet_type = bet.get("bet_type", "bet")
            won = False
            winnings = 0

            if bet_type == "bet":
                if bet["horse"] == winner_id:
                    winnings = int(bet["amount"] * winner_horse["odds"])
                    won = True
            elif bet_type == "place":
                if bet["horse"] in (winner_id, second_id, third_id):
                    winnings = int(bet["amount"] * get_place_multiplier(int(bet["horse"])))
                    won = True
            elif bet_type == "lin":
                picked = {int(bet["horse"]), int(bet.get("horse2", -1))}
                if picked == {winner_id, second_id}:
                    winnings = int(bet["amount"] * get_lin_multiplier(winner_id, second_id))
                    won = True

            settlement_entries.append(
                {
                    "user_id": int(user_id),
                    "amount": int(bet["amount"]),
                    "status": "won" if won else "lost",
                    "payout": winnings if won else 0,
                    "history_id": bet.get("history_id"),
                    "name": bet["name"],
                    "bet_type": bet_type,
                }
            )

        settlement_result = await run_db(settle_race_round, chat_id, settlement_entries)
        if not settlement_result.get("applied", False):
            await message.reply_text("ℹ️ 呢場賽事已經結算，唔會重覆派彩。")
            return

        applied_user_ids = set(settlement_result.get("applied_user_ids", []))
        has_winner = False
        for entry in settlement_entries:
            if entry["user_id"] not in applied_user_ids or int(entry["payout"]) <= 0:
                continue
            bet_label = "獨贏" if entry["bet_type"] == "bet" else "位置" if entry["bet_type"] == "place" else "連贏"
            result_text += f"🎉 恭喜 {entry['name']}（{bet_label}）贏得 ${entry['payout']} 金幣！\n"
            has_winner = True

        if not has_winner:
            result_text += "💸 本局大家都睇錯晒，莊家通殺！\n"

        await message.reply_text(result_text)
    except Exception:
        logger.exception("run_game failed for chat %s", chat_id)
        refund_result = await run_db(refund_open_bets, chat_id, bets_snapshot, "refunded_error")
        try:
            if refund_result.get("applied", False):
                await message.reply_text("⚠️ 賽事中途出錯，今場已自動退款，請稍後再試。")
            else:
                await message.reply_text("⚠️ 賽事中途出錯，但本場已處理，唔會重覆退款。")
        except Exception:
            logger.exception("Failed to send run_game error message for chat %s", chat_id)
    finally:
        async with lock:
            game = get_chat_game(chat_id)
            game["status"] = "idle"
            game["bets"] = {}
            game["horses"] = HORSES_DATA.copy()
            game["race_context"] = None
            await clear_persisted_chat_game(chat_id)
        try:
            await close_betting_buttons(context, chat_id, game)
        except Exception:
            logger.exception("Failed to clear betting buttons in finally for chat %s", chat_id)


async def cancel_game(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    if message is None or chat is None:
        return
    if not await require_admin(update, context):
        return

    chat_id = chat.id
    lock = get_chat_lock(chat_id)
    refunded_count = 0
    async with lock:
        game = get_chat_game(chat_id)
        if game["status"] != "betting":
            await message.reply_text("ℹ️ 目前冇可取消嘅開盤賽事。")
            return

        refund_result = await run_db(refund_open_bets, chat_id, game["bets"], "refunded", ("betting",), "settled")
        if not refund_result.get("applied", False):
            await message.reply_text("ℹ️ 呢場賽事已處理，唔會重覆退款。")
            return
        refunded_count = len(refund_result.get("refunded_user_ids", []))
        game["status"] = "idle"
        game["bets"] = {}
        game["horses"] = HORSES_DATA.copy()
        game["race_context"] = None
        await clear_persisted_chat_game(chat_id)

    await close_betting_buttons(context, chat_id, game)
    await message.reply_text(f"🛑 賽事已取消，已退款俾 {refunded_count} 位玩家。")
