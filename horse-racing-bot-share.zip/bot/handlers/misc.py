from telegram import Update
from telegram.ext import ContextTypes

UNSUPPORTED_COMMANDS = {
    "wheel": "輪盤",
    "odd": "輪盤 - 單數",
    "even": "輪盤 - 雙數",
    "small": "輪盤 - 細",
    "big": "輪盤 - 大",
    "g1": "輪盤 - 第一組",
    "g2": "輪盤 - 第二組",
    "g3": "輪盤 - 第三組",
    "num": "輪盤 - 多號碼",
    "startbroadcast": "群組廣播",
    "stopbroadcast": "群組廣播",
    "checkbroadcast": "群組廣播",
    "settopic": "Topic 廣播設定",
    "settopiclink": "Topic 廣播設定",
    "cleartopic": "Topic 廣播設定",
    "checktopic": "Topic 廣播設定",
    "buy": "買馬 (PM)",
    "myhorses": "買馬 (PM)",
    "rename": "買馬 (PM)",
    "cup": "盃賽 (PM)",
    "mycups": "盃賽 (PM)",
    "renamecup": "盃賽 (PM)",
    "refund": "搞笑 / 彩蛋",
}


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if message is None:
        return
    help_text = (
        "🏇 *馬場大享 - 幫助*\n\n"
        "【投注】\n"
        "/bet <號碼> <金額> - 獨贏（支援百分比，例如 `/bet 1 10%`）\n"
        "/place <號碼> <金額> - 位置（前三名都當贏，支援百分比）\n"
        "/lin <號碼1> <號碼2> <金額> - 連贏（支援百分比）\n\n"
        "【查詢】\n"
        "/balance - 餘額\n"
        "/history - 投注紀錄\n"
        "/rank - 最有錢馬主\n"
        "/grouprank - 群組累積分數榜\n"
        "/groupcontrib - 成員貢獻榜\n"
        "/yesterday - 昨日群組冠軍\n\n"
        "【賽事】\n"
        "/startrace 或 /open - 開盤\n"
        "/run - 開跑（管理員）\n"
        "/cancel - 取消賽事並退款（管理員）\n\n"
        "【賽事引擎】\n"
        "每場每隻馬都有：表面狀態 + 馬主私密狀態\n"
        "再疊加場地隨機因素 + 隨機祝福（約10%機率）\n\n"
        "【其他】\n"
        "/help - 幫助\n\n"
        "✨ 新玩家預設免費金幣：100"
    )
    await message.reply_text(help_text, parse_mode="Markdown")


async def unsupported_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if message is None:
        return
    raw = (message.text or "").split("@")[0].strip()
    cmd = raw[1:].split()[0] if raw.startswith("/") else raw
    feature_name = UNSUPPORTED_COMMANDS.get(cmd, "該功能")
    await message.reply_text(f"🚧 `{cmd}`（{feature_name}）仲開發中，敬請期待。", parse_mode="Markdown")
