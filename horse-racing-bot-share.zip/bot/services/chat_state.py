import asyncio
import time

from telegram.ext import ContextTypes

from bot.config import CHAT_STATE_TTL_SECONDS
from bot.db import run_db
from bot.repositories.session_repo import clear_race_session, save_race_session
from bot.services.game_engine import HORSES_DATA
from bot.types import GameState

# Per-chat race state so multiple groups can play independently.
games_by_chat_id: dict[int, GameState] = {}
game_locks: dict[int, asyncio.Lock] = {}
chat_last_active: dict[int, float] = {}


def mark_chat_active(chat_id: int) -> None:
    chat_last_active[chat_id] = time.time()


def get_chat_game(chat_id: int) -> GameState:
    mark_chat_active(chat_id)
    if chat_id not in games_by_chat_id:
        games_by_chat_id[chat_id] = {
            "status": "idle",
            "bets": {},
            "horses": HORSES_DATA.copy(),
            "bet_message_id": None,
            "race_context": None,
        }
    return games_by_chat_id[chat_id]


def get_chat_lock(chat_id: int) -> asyncio.Lock:
    if chat_id not in game_locks:
        game_locks[chat_id] = asyncio.Lock()
    return game_locks[chat_id]


async def persist_chat_game(chat_id: int) -> None:
    game = get_chat_game(chat_id)
    await run_db(save_race_session, chat_id, game)


async def clear_persisted_chat_game(chat_id: int) -> None:
    await run_db(clear_race_session, chat_id)


async def cleanup_idle_chat_state(_: ContextTypes.DEFAULT_TYPE) -> None:
    now = time.time()
    stale_chat_ids = []
    for chat_id, last_active in list(chat_last_active.items()):
        if now - last_active < CHAT_STATE_TTL_SECONDS:
            continue
        game = games_by_chat_id.get(chat_id)
        if game and game.get("status") == "idle":
            stale_chat_ids.append(chat_id)
    for chat_id in stale_chat_ids:
        games_by_chat_id.pop(chat_id, None)
        game_locks.pop(chat_id, None)
        chat_last_active.pop(chat_id, None)
