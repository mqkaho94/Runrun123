import random

from bot.config import BLESSING_CHANCE

# Horse data. Higher weight means higher winning probability.
HORSES_DATA = [
    {"id": 1, "name": "🐴 閃電傳奇 (大熱門)", "weight": 40, "odds": 1.8, "style": "speed"},
    {"id": 2, "name": "🐴 浪漫勇士 (次熱)", "weight": 30, "odds": 2.5, "style": "stamina"},
    {"id": 3, "name": "🐴 金鎗六十 (中堅)", "weight": 20, "odds": 4.0, "style": "balanced"},
    {"id": 4, "name": "🐴 爆冷神話 (冷門)", "weight": 10, "odds": 8.5, "style": "mudder"},
]

TRACK_CONDITIONS = [
    {"name": "☀️ 晴天快地", "effects": {"speed": 12, "stamina": 4, "balanced": 6, "mudder": -8}},
    {"name": "🌧️ 雨戰泥地", "effects": {"speed": -6, "stamina": 5, "balanced": 2, "mudder": 14}},
    {"name": "💨 逆風賽道", "effects": {"speed": -4, "stamina": 12, "balanced": 3, "mudder": 1}},
    {"name": "🌤️ 標準草地", "effects": {"speed": 5, "stamina": 5, "balanced": 8, "mudder": 2}},
]


def get_horse_by_id(horse_id: int) -> dict | None:
    return next((horse for horse in HORSES_DATA if horse["id"] == horse_id), None)


def get_place_multiplier(horse_id: int) -> float:
    horse = get_horse_by_id(horse_id)
    if horse is None:
        return 1.0
    return max(1.2, round(float(horse["odds"]) * 0.6, 2))


def get_lin_multiplier(horse_id_1: int, horse_id_2: int) -> float:
    horse1 = get_horse_by_id(horse_id_1)
    horse2 = get_horse_by_id(horse_id_2)
    if horse1 is None or horse2 is None:
        return 1.0
    return round((float(horse1["odds"]) + float(horse2["odds"])) * 0.9, 2)


def describe_public_state(value: int) -> str:
    if value >= 12:
        return "🔥 表面狀態：極佳"
    if value >= 6:
        return "✨ 表面狀態：良好"
    if value >= 0:
        return "🙂 表面狀態：平穩"
    if value >= -8:
        return "😵 表面狀態：一般"
    return "🥶 表面狀態：低迷"


def describe_private_state(value: int) -> str:
    if value >= 12:
        return "🧠 馬主內線：爆發邊緣"
    if value >= 6:
        return "🧠 馬主內線：狀態暗升"
    if value >= 0:
        return "🧠 馬主內線：正常"
    if value >= -8:
        return "🧠 馬主內線：略帶隱憂"
    return "🧠 馬主內線：疑似腳軟"


def build_race_context() -> dict:
    track = random.choice(TRACK_CONDITIONS)
    blessing: dict | None = None
    if random.random() <= BLESSING_CHANCE:
        blessed_horse = random.choice(HORSES_DATA)
        blessing_bonus = random.randint(8, 18)
        blessing = {
            "horse_id": blessed_horse["id"],
            "name": "🍀 天降祝福",
            "bonus": blessing_bonus,
            "text": f"🍀 特殊事件：{blessed_horse['name']} 獲得祝福（+{blessing_bonus}%）",
        }

    horse_factors: dict[int, dict] = {}
    for horse in HORSES_DATA:
        public_factor = random.randint(-10, 14)
        private_factor = random.randint(-12, 16)
        track_factor = int(track["effects"].get(horse["style"], 0))
        blessing_factor = 0
        if blessing and blessing["horse_id"] == horse["id"]:
            blessing_factor = int(blessing["bonus"])
        total = public_factor + private_factor + track_factor + blessing_factor
        horse_factors[horse["id"]] = {
            "public_factor": public_factor,
            "private_factor": private_factor,
            "track_factor": track_factor,
            "blessing_factor": blessing_factor,
            "total_factor": total,
        }

    return {"track": track, "blessing": blessing, "horses": horse_factors, "owners": {}}


def get_effective_weights(race_context: dict) -> dict[int, int]:
    weights: dict[int, int] = {}
    for horse in HORSES_DATA:
        factors = race_context["horses"][horse["id"]]
        multiplier = max(0.3, 1 + (factors["total_factor"] / 100))
        weights[horse["id"]] = max(1, int(horse["weight"] * multiplier))
    return weights


def pick_weighted_winner(weight_map: dict[int, int], excluded: set[int] | None = None) -> int:
    excluded = excluded or set()
    candidates = [horse_id for horse_id in weight_map if horse_id not in excluded]
    weights = [weight_map[horse_id] for horse_id in candidates]
    return int(random.choices(candidates, weights=weights, k=1)[0])


def format_hidden_state_line(race_context: dict, horse_id: int) -> str:
    horse = get_horse_by_id(horse_id)
    factor = race_context["horses"][horse_id]["private_factor"]
    return f"{horse['name']}: {describe_private_state(factor)} ({factor:+}%)"


def parse_bet_amount(raw_amount: str, current_balance: int) -> int:
    text = raw_amount.strip()
    if text.endswith("%"):
        pct_raw = text[:-1].strip()
        if not pct_raw:
            raise ValueError("百分比格式錯誤")
        pct = int(pct_raw)
        if pct <= 0 or pct > 100:
            raise ValueError("百分比必須 1-100")
        amount = int(current_balance * (pct / 100))
        return max(amount, 1)
    amount = int(text)
    if amount <= 0:
        raise ValueError("金額必須大於 0")
    return amount
