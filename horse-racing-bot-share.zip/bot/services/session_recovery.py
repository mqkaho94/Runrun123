import logging

from bot.db import run_db
from bot.repositories.bet_repo import refund_open_bets
from bot.repositories.session_repo import clear_race_session, load_active_race_sessions

logger = logging.getLogger(__name__)


async def recover_inflight_sessions() -> None:
    sessions = await run_db(load_active_race_sessions)
    if not sessions:
        return
    for session in sessions:
        chat_id = int(session["chat_id"])
        bets = session.get("bets", {})
        await run_db(
            refund_open_bets,
            chat_id,
            bets,
            "refunded_restart",
            ("betting", "running"),
            "settled",
        )
        await run_db(clear_race_session, chat_id)
    logger.warning("Recovered %s in-flight sessions with auto-refund", len(sessions))
