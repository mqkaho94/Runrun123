import asyncio
import sqlite3
import threading
from pathlib import Path
from typing import Any, Callable

from bot.config import DB_BUSY_TIMEOUT_MS, DB_PATH

db_lock = threading.Lock()
db_conn: sqlite3.Connection | None = None


def get_db_conn() -> sqlite3.Connection:
    global db_conn
    if db_conn is None:
        conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute(f"PRAGMA busy_timeout={DB_BUSY_TIMEOUT_MS}")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        db_conn = conn
    return db_conn


def init_db() -> None:
    db_file = Path(DB_PATH)
    db_file.parent.mkdir(parents=True, exist_ok=True)
    conn = get_db_conn()
    with db_lock:
        wallet_columns = {
            row[1]
            for row in conn.execute("PRAGMA table_info(wallets)").fetchall()
        }
        if wallet_columns and "chat_id" not in wallet_columns:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS wallets_new (
                    chat_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    balance INTEGER NOT NULL,
                    PRIMARY KEY (chat_id, user_id)
                )
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO wallets_new (chat_id, user_id, balance)
                SELECT 0, user_id, balance
                FROM wallets
                """
            )
            conn.execute("DROP TABLE wallets")
            conn.execute("ALTER TABLE wallets_new RENAME TO wallets")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS wallets (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                balance INTEGER NOT NULL,
                PRIMARY KEY (chat_id, user_id)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS bet_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_name TEXT NOT NULL,
                horse_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                bet_type TEXT NOT NULL,
                status TEXT NOT NULL,
                payout INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                result_at TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_bet_history_chat_user_id_desc
            ON bet_history (chat_id, user_id, id DESC)
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_bet_history_chat_result_at
            ON bet_history (chat_id, result_at)
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_bet_history_chat_status
            ON bet_history (chat_id, status)
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS race_sessions (
                chat_id INTEGER PRIMARY KEY,
                status TEXT NOT NULL,
                race_context_json TEXT,
                bet_message_id INTEGER,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS group_stats (
                chat_id INTEGER PRIMARY KEY,
                net_score INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_group_stats_net_score
            ON group_stats (net_score DESC)
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS group_user_stats (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_name TEXT NOT NULL,
                net_score INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (chat_id, user_id)
            )
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_group_user_stats_chat_score
            ON group_user_stats (chat_id, net_score DESC)
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS group_user_daily_stats (
                stat_date TEXT NOT NULL,
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_name TEXT NOT NULL,
                net_score INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (stat_date, chat_id, user_id)
            )
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_group_user_daily_chat_date_score
            ON group_user_daily_stats (chat_id, stat_date, net_score DESC)
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS race_session_bets (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                horse INTEGER NOT NULL,
                horse2 INTEGER,
                amount INTEGER NOT NULL,
                name TEXT NOT NULL,
                bet_type TEXT NOT NULL,
                history_id INTEGER,
                PRIMARY KEY (chat_id, user_id)
            )
            """
        )
        columns = {
            row[1]
            for row in conn.execute("PRAGMA table_info(bet_history)").fetchall()
        }
        if "horse_id_2" not in columns:
            conn.execute("ALTER TABLE bet_history ADD COLUMN horse_id_2 INTEGER")
        conn.commit()


async def run_db(func: Callable[..., Any], *args: Any) -> Any:
    return await asyncio.to_thread(func, *args)
