import asyncio

from telegram.ext import Application, CallbackQueryHandler, CommandHandler

from bot.config import TOKEN, setup_logging, validate_env
from bot.db import init_db
from bot.handlers.admin import reset_wallets
from bot.handlers.history import group_contrib, group_rank, history, yesterday
from bot.handlers.misc import UNSUPPORTED_COMMANDS, help_command, unsupported_command
from bot.handlers.race import (
    bet_command,
    cancel_game,
    handle_bet,
    lin_command,
    open_game,
    place_command,
    run_game,
)
from bot.handlers.wallet import balance, leaderboard, start
from bot.services.chat_state import cleanup_idle_chat_state
from bot.services.session_recovery import recover_inflight_sessions


def build_application() -> Application:
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("balance", balance))
    application.add_handler(CommandHandler("history", history))
    application.add_handler(CommandHandler("leaderboard", leaderboard))
    application.add_handler(CommandHandler("rank", leaderboard))
    application.add_handler(CommandHandler("grouprank", group_rank))
    application.add_handler(CommandHandler("groupcontrib", group_contrib))
    application.add_handler(CommandHandler("yesterday", yesterday))
    application.add_handler(CommandHandler("bet", bet_command))
    application.add_handler(CommandHandler("place", place_command))
    application.add_handler(CommandHandler("lin", lin_command))
    application.add_handler(CommandHandler("startrace", open_game))
    application.add_handler(CommandHandler("open", open_game))
    application.add_handler(CommandHandler("run", run_game))
    application.add_handler(CommandHandler("cancel", cancel_game))
    application.add_handler(CommandHandler("reset_wallets", reset_wallets))
    application.add_handler(CommandHandler(list(UNSUPPORTED_COMMANDS.keys()), unsupported_command))
    application.add_handler(CallbackQueryHandler(handle_bet, pattern=r"^bet_"))
    if application.job_queue:
        application.job_queue.run_repeating(cleanup_idle_chat_state, interval=600, first=600)
    return application


def main() -> None:
    setup_logging()
    validate_env()
    init_db()
    asyncio.run(recover_inflight_sessions())

    application = build_application()
    application.run_polling(allowed_updates=["message", "callback_query"])


if __name__ == "__main__":
    main()
