"""Horse racing bot package."""
