from typing import Any, TypedDict


class BetData(TypedDict, total=False):
    horse: int
    horse2: int | None
    amount: int
    name: str
    bet_type: str
    history_id: int | None


class GameState(TypedDict):
    status: str
    bets: dict[int, BetData]
    horses: list[dict[str, Any]]
    bet_message_id: int | None
    race_context: dict[str, Any] | None
